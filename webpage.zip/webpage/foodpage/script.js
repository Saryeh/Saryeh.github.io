$(document).ready(function(){
  $('.your-class').slick({
    setting-name: setting-value
  });
});